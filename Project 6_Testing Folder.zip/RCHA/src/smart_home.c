#include "smart_home.h"
#include <stdio.h>
#include <string.h>

// ---------------- Hardware Instances ----------------
GPIO_TypeDef GPIOA_instance = {0};
GPIO_TypeDef GPIOB_instance = {0};
GPIO_TypeDef GPIOC_instance = {0};
TIM_TypeDef  TIM2_instance  = {0};
RCC_TypeDef  RCC_instance   = {0};

// ---------------- Pointers ----------------
GPIO_TypeDef *GPIOA = &GPIOA_instance;
GPIO_TypeDef *GPIOB = &GPIOB_instance;
GPIO_TypeDef *GPIOC = &GPIOC_instance;
TIM_TypeDef  *TIM2  = &TIM2_instance;
RCC_TypeDef  *RCC   = &RCC_instance;

// ---------------- States ----------------
uint8_t fanState = 0;
uint8_t lightState = 0;

// ---------------- Motor / PWM ----------------
void GPIO_Init_Motordriver(void)
{
    RCC->AHB1ENR |= (1 << 1);
    GPIOB->MODER &= ~((3 << (2 * 8)) | (3 << (2 * 9)));
    GPIOB->MODER |=  ((1 << (2 * 8)) | (1 << (2 * 9)));
    GPIOB->ODR |= (1 << 8);
}

void GPIO_Init_MotorRelay(void)
{
    RCC->AHB1ENR |= (1 << 1);
    GPIOB->MODER &= ~((3 << (2 * 10)) | (3 << (2 * 11)));
    GPIOB->MODER |=  ((1 << (2 * 10)) | (1 << (2 * 11)));
    GPIOB->ODR |= (1 << 10);
}

void pwm_gpio_init(void)
{
    RCC->AHB1ENR |= (1 << 0);
    RCC->APB1ENR |= (1 << 0);
    GPIOA->MODER &= ~(3 << (3 * 2));
    GPIOA->MODER |=  (2 << (3 * 2));
    GPIOA->AFR[0] &= ~(0xF << (3 * 4));
    GPIOA->AFR[0] |=  (1 << (3 * 4));
    TIM2->PSC = 16-1;
    TIM2->ARR = 1600-1;
    TIM2->CCMR2 &= ~(0xFF);
    TIM2->CCMR2 |= (6 << 12);
    TIM2->CCMR2 |= (1 << 11);
    TIM2->CCER  |= (1 << 12);
    TIM2->CR1   |= (1 << 7);
    TIM2->CR1   |= (1 << 0);
}

void pwm_enable(uint32_t val)
{
    if (val > TIM2->ARR) val = TIM2->ARR;
    TIM2->CCR4 = val;
}

// ---------------- Buttons / LEDs ----------------
void button_init(void)
{
    RCC->AHB1ENR |= (1 << 1);
    GPIOB->MODER &= ~((3 << (7*2)) | (3 << (3*2)));
    GPIOB->PUPDR &= ~((3 << (7*2)) | (3 << (3*2)));
    GPIOB->PUPDR |=  ((1 << (7*2)) | (1 << (3*2)));
}

void led_init(void)
{
    RCC->AHB1ENR |= (1 << 2);
    GPIOC->MODER &= ~(3 << (6*2));
    GPIOC->MODER |= (1 << (6*2));
}

// ---------------- FAN / LED actions ----------------
void fan_on(void)  { pwm_enable(1000); fanState = 1; lprint(0,"FAN ON"); USART3_Transmit("FAN ON\n"); }
void fan_off(void) { pwm_enable(0); fanState = 0; lprint(0,"FAN OFF"); USART3_Transmit("FAN OFF\n"); }
void led_on(void)  { lightState = 1; lprint(0,"LED ON"); USART3_Transmit("LED ON\n"); }
void led_off(void) { lightState = 0; lprint(0,"LED OFF"); USART3_Transmit("LED OFF\n"); }

void send_states_to_pc(void)
{
    char msg[30];
    sprintf(msg, "LIGHT: %s\n", lightState ? "ON" : "OFF");
    USART3_Transmit(msg);
    sprintf(msg, "FAN: %s\n", fanState ? "ON" : "OFF");
    USART3_Transmit(msg);
}

void process_uart_command(void)
{
    if(!USART3_Available()) return;
    char c = USART3_ReadChar();
    if(c == 'F') fan_on();
    else if(c == 'f') fan_off();
    else if(c == 'L') led_on();
    else if(c == 'l') led_off();
}

// ---------------- IR Remote processing ----------------
void DisplayIRCode(uint32_t code)
{
    if(code == 0x1FE48B7) led_on();
    else if(code == 0x1FE807F) fan_on();
}
