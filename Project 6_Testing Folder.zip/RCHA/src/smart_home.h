#ifndef SMART_HOME_H
#define SMART_HOME_H

#include <stdint.h>

// Hardware mock structs
typedef struct {
    volatile uint32_t MODER;
    volatile uint32_t ODR;
    volatile uint32_t AFR[2];
    volatile uint32_t PUPDR;
} GPIO_TypeDef;

typedef struct {
    volatile uint32_t PSC;
    volatile uint32_t ARR;
    volatile uint32_t CCR4;
    volatile uint32_t CCMR2;
    volatile uint32_t CCER;
    volatile uint32_t CR1;
} TIM_TypeDef;

typedef struct {
    volatile uint32_t AHB1ENR;
    volatile uint32_t APB1ENR;
} RCC_TypeDef;

// Extern pointers for code
extern GPIO_TypeDef *GPIOA;
extern GPIO_TypeDef *GPIOB;
extern GPIO_TypeDef *GPIOC;
extern TIM_TypeDef  *TIM2;
extern RCC_TypeDef  *RCC;

// States
extern uint8_t fanState;
extern uint8_t lightState;

// Hardware dependent functions (extern, implemented in test mocks)
extern void lprint(uint8_t pos, const char *msg);
extern void USART3_Transmit(const char *msg);
extern int USART3_Available(void);
extern char USART3_ReadChar(void);

// Function declarations
void GPIO_Init_Motordriver(void);
void GPIO_Init_MotorRelay(void);
void pwm_gpio_init(void);
void pwm_enable(uint32_t val);
void button_init(void);
void led_init(void);
void fan_on(void);
void fan_off(void);
void led_on(void);
void led_off(void);
void send_states_to_pc(void);
void process_uart_command(void);
void DisplayIRCode(uint32_t code);

#endif
