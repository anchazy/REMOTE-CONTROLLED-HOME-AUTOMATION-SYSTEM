#include "unity.h"
#include "smart_home.h"

// ---------------- Mock implementations ----------------
void lprint(uint8_t pos, const char *msg) {}
void USART3_Transmit(const char *msg) {}
int USART3_Available(void) { return 1; }
char USART3_ReadChar(void) { return 'F'; }  // Default mock

// ---------------- Unity test setup ----------------
void setUp(void) {}
void tearDown(void) {}

// ---------------- Tests ----------------

// 1. Fan ON sets fanState to 1
void test_fan_on_should_set_state(void)
{
    fanState = 0;
    fan_on();
    TEST_ASSERT_EQUAL_UINT8(1, fanState);
}

// 2. Fan OFF sets fanState to 0
void test_fan_off_should_set_state(void)
{
    fanState = 1;
    fan_off();
    TEST_ASSERT_EQUAL_UINT8(0, fanState);
}

// 3. LED ON sets lightState to 1
void test_led_on_should_set_state(void)
{
    lightState = 0;
    led_on();
    TEST_ASSERT_EQUAL_UINT8(1, lightState);
}

// 4. LED OFF sets lightState to 0
void test_led_off_should_set_state(void)
{
    lightState = 1;
    led_off();
    TEST_ASSERT_EQUAL_UINT8(0, lightState);
}

// 5. UART command 'F' turns fan ON
void test_process_uart_command_turns_fan_on(void)
{
    fanState = 0;
    process_uart_command();
    TEST_ASSERT_EQUAL_UINT8(1, fanState);
}

// 6. UART command 'f' turns fan OFF (if implemented)

// 7. DisplayIRCode for LED ON code
void test_DisplayIRCode_turns_led_on(void)
{
    lightState = 0;
    DisplayIRCode(0x1FE48B7);  // Example IR code
    TEST_ASSERT_EQUAL_UINT8(1, lightState);
}



// 9. Fan and LED can be ON simultaneously
void test_fan_and_led_on_together(void)
{
    fanState = 0;
    lightState = 0;
    fan_on();
    led_on();
    TEST_ASSERT_EQUAL_UINT8(1, fanState);
    TEST_ASSERT_EQUAL_UINT8(1, lightState);
}

// 10. UART Available check returns 1
void test_usart_available_returns_true(void)
{
    TEST_ASSERT_EQUAL_UINT8(1, USART3_Available());
}
