/* USER CODE BEGIN Header */
/* HOME AUTOMATION - BARE-METAL VERSION */
/* IR and UART processing is handled in the main while(1) loop. */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "lcd.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define CODE_BUFFER_SIZE 21    // Store last 10 codes

/* IR Remote Button Codes */
#define IR_POWER       33441975
#define IR_MODE        33446055
#define IR_MUTE        33454215
#define IR_PLAYPAUSE   33456255
#define IR_BACK        33439935
#define IR_FORWARD     33472575
#define IR_EQ          33431775
#define IR_VOL_MINUS   33464415
#define IR_VOL_PLUS    33448095
#define IR_0           33480735
#define IR_RPT         33427695
#define IR_USD         33460335
#define IR_1           33444015
#define IR_2           33478695
#define IR_3           33486855
#define IR_4           33435855
#define IR_5           33468495
#define IR_6           33452175
#define IR_7           33423615
#define IR_8           33484815
#define IR_9           33462375
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
volatile uint32_t runtimeStatsTimer = 0;
uint32_t tempCode;
uint8_t bitIndex;
uint8_t cmd;
uint8_t cmdli;
uint32_t code;
uint32_t codeBuffer[CODE_BUFFER_SIZE];
uint8_t codeIndex = 0;
char msg[48];
int len = 0;
uint8_t GetData;
uint8_t FanStatus = 0; // 0=OFF, 1=ON
uint8_t LightLevel = 0; // 0=OFF, 1=LOW, 2=MEDIUM, 3=HIGH (Replaces LightStatus)
/* Communication between ISR and main */
volatile uint32_t lastCodeFromISR = 0;
volatile uint8_t newCodeFlag = 0;
uint8_t tx_buffer[27] = "SILICON SQUAD ";
uint8_t rx_indx = 0;
uint8_t transfer_cplt = 0;
uint8_t rx_buffer[50];
uint8_t rx_data[1];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */
void updateLED(void);
void updateFan(uint32_t duty);
void irRecv_loop(void);
void motor_config(void);
void updateLCD(void); // New helper function for LCD update
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/**
  * @brief Update LCD with current fan and light status.
  * @param None
  * @retval None
  */
void updateLCD(void) {
    char fan_msg[16], led_msg[16];
    const char* led_status;

    // Determine LED status string
    switch(LightLevel) {
        case 0: led_status = "OFF"; break;
        case 1: led_status = "LOW"; break;
        case 2: led_status = "MED"; break;
        case 3: led_status = "HIGH"; break;
        default: led_status = "ERR"; break;
    }

    sprintf(fan_msg, "FAN %s", FanStatus ? "ON" : "OFF");
    sprintf(led_msg, "LED %s", led_status);

    LcdClear();
    lprint(0x80, led_msg);
    lprint(0xC0, fan_msg);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void) {
	/* USER CODE BEGIN 1 */
	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */
	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_USART3_UART_Init();
	MX_TIM1_Init();
	MX_TIM3_Init();

	/* USER CODE BEGIN 2 */
	/* Start base timer used by IR measurement (also used for LED PWM) */
	/* Keep base running so EXTI handler can read counter for IR timing */
	HAL_TIM_Base_Start(&htim1);
	__HAL_TIM_SET_COUNTER(&htim1, 0);

	/* Start TIM1 PWM channel (so timer runs in PWM mode and output toggles on PA8) */
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);

	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET);

	/* Start UART receive interrupt for single-byte reception */
	HAL_UART_Receive_IT(&huart3, rx_data, 1);

	/* Initialize peripherals used in loop */
	LcdInit();
	motor_config();

	/* Initial LCD display */
	updateLCD();
	/* USER CODE END 2 */

	/* Infinite loop (no RTOS) */
	while (1) {
		// Poll for new IR codes
		irRecv_loop();

		// Delay to maintain a processing interval (100ms)
		HAL_Delay(100);
	}

	/* USER CODE BEGIN 3 */
	/* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration (84 MHz)
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators (HSI as source, PLL ON) */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;  // SYSCLK = 84 MHz
  RCC_OscInitStruct.PLL.PLLQ = 7;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB, and APB buses clocks */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                              | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;  // 42 MHz
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;  // 84 MHz

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void) {
    TIM_ClockConfigTypeDef sClockSourceConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig = {0};
    TIM_OC_InitTypeDef sConfigOC = {0};

    htim1.Instance = TIM1;
    htim1.Init.Prescaler = 71;             // 1 MHz timer clock
    htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim1.Init.Period = 999;               // 1 kHz PWM frequency (Period determines resolution)
    htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim1.Init.RepetitionCounter = 0;
    htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    if (HAL_TIM_Base_Init(&htim1) != HAL_OK) Error_Handler();

    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
    if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK) Error_Handler();

    if (HAL_TIM_PWM_Init(&htim1) != HAL_OK) Error_Handler();

    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK) Error_Handler();

    sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = 0;  // start with LED off
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
    if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK) Error_Handler();

    HAL_TIM_MspPostInit(&htim1);
}


/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void) {
	TIM_ClockConfigTypeDef sClockSourceConfig = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };
	TIM_OC_InitTypeDef sConfigOC = { 0 };

	htim3.Instance = TIM3;
	htim3.Init.Prescaler = 71; // 1MHz Timer Clock
	htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim3.Init.Period = 100; // 10kHz PWM frequency (1MHz / 100)
	htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim3) != HAL_OK) {
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_TIM_PWM_Init(&htim3) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}
	sConfigOC.OCMode = TIM_OCMODE_PWM1;
	sConfigOC.Pulse = 0; // Start with fan off
	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigOC.OCFastMode = TIM_OCFAST_ENABLE;
	if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK) {
		Error_Handler();
	}
	HAL_TIM_MspPostInit(&htim3); // This ensures PA6 is configured for PWM
}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void) {
	huart3.Instance = USART3;
	huart3.Init.BaudRate = 115200;
	huart3.Init.WordLength = UART_WORDLENGTH_8B;
	huart3.Init.StopBits = UART_STOPBITS_1;
	huart3.Init.Parity = UART_PARITY_NONE;
	huart3.Init.Mode = UART_MODE_TX_RX;
	huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart3.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart3) != HAL_OK) {
		Error_Handler();
	}
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void) {
	GPIO_InitTypeDef GPIO_InitStruct = { 0 };

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/* Configure GPIO pin output Level */
	// PC0 (AIN1), PC1 (AIN2), PC6 (LCD)
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_6, GPIO_PIN_RESET);
	// PA3 (STBY), PA4 (LCD)
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3 | GPIO_PIN_4, GPIO_PIN_RESET);

	/* Configure PC0, PC1, PC6 pins as output (PC0=AIN1, PC1=AIN2) */
	GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_6;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/* Configure PA3, PA4 pins as output (PA3=STBY) */
	GPIO_InitStruct.Pin = GPIO_PIN_3 | GPIO_PIN_4;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/* Configure PB11 (IR Receiver) pin as falling edge interrupt */
	GPIO_InitStruct.Pin = GPIO_PIN_11;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/* Configure PB3 (FAN Button) and PB4 (LIGHT Button) pins as rising edge interrupt */
	GPIO_InitStruct.Pin = GPIO_PIN_3 | GPIO_PIN_4;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/* EXTI interrupt init*/
	HAL_NVIC_SetPriority(EXTI3_IRQn, 2, 0);
	HAL_NVIC_EnableIRQ(EXTI3_IRQn);

	HAL_NVIC_SetPriority(EXTI4_IRQn, 2, 0);
	HAL_NVIC_EnableIRQ(EXTI4_IRQn);

	HAL_NVIC_SetPriority(EXTI15_10_IRQn, 1, 0);
	HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

/* USER CODE BEGIN 4 */

/* Convert LED status & level to PWM duty */
void updateLED(void) {
    uint32_t duty_percent = 0;
    switch(LightLevel) {
        case 0: duty_percent = 0; break;
        case 1: duty_percent = 30; break; // Low ~30%
        case 2: duty_percent = 60; break; // Medium ~60%
        case 3: duty_percent = 100; break; // High 100%
    }
    /* Scale percent to TIM1 period (Period is 999) */
    uint32_t period = htim1.Init.Period;
    uint32_t compare = (period * duty_percent) / 100;
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, compare);
}

/* Convert Fan status & speed to PWM duty */
void updateFan(uint32_t duty_percent) {
    uint32_t period = htim3.Init.Period; // Period is 100
    uint32_t compare = (period * duty_percent) / 100;

    if(FanStatus) {
        // Set direction (e.g., forward: AIN1=HIGH, AIN2=LOW) and enable STBY
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_SET); // STBY ON
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET); // AIN1 HIGH
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); // AIN2 LOW

        HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, compare); // Set PWM duty on PWMA (PA6)
    } else {
        // Set PWM to zero, and set STBY to LOW for low-power mode
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET); // STBY OFF
    }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	/* ===== IR REMOTE INPUT (PB11) ===== */
	if (GPIO_Pin == GPIO_PIN_11) {
		uint32_t t = __HAL_TIM_GET_COUNTER(&htim1);

		if (t > 8000) {
			tempCode = 0;
			bitIndex = 0;
		} else if (t > 1700) {
			if (bitIndex < 32)
				tempCode |= (1UL << (31 - bitIndex));
			bitIndex++;
		} else if (t > 1000) {
			if (bitIndex < 32)
				tempCode &= ~(1UL << (31 - bitIndex));
			bitIndex++;
		}

		if (bitIndex == 32) {
			cmdli = (uint8_t) (~tempCode);
			cmd = (uint8_t) (tempCode >> 8);

			if (cmdli == cmd) {
				code = tempCode;
				codeBuffer[codeIndex] = code;
				codeIndex = (codeIndex + 1) % CODE_BUFFER_SIZE;

				lastCodeFromISR = code;
				newCodeFlag = 1;
			}
			bitIndex = 0;
		}

		__HAL_TIM_SET_COUNTER(&htim1, 0);
	}

	/* ===== MANUAL OVERRIDE: FAN BUTTON (PB3) ===== */
	else if (GPIO_Pin == GPIO_PIN_3) {
		FanStatus = !FanStatus;

		if (FanStatus) {
            // Fan ON to a default speed (e.g., 50%)
			updateFan(50);
		} else {
            // Fan OFF
			updateFan(0);
		}
        updateLCD();
	}

	/* ===== MANUAL OVERRIDE: LIGHT BUTTON (PB4) - Now using LightLevel ===== */
	else if (GPIO_Pin == GPIO_PIN_4) {
        // Toggle from any ON state (1, 2, 3) to OFF (0), or OFF to HIGH (3)
        if (LightLevel == 0) {
            LightLevel = 3;
        } else {
            LightLevel = 0;
        }
        updateLED();

		updateLCD(); // Call the centralized LCD update
	}
}

/* IR Remote control loop */
void irRecv_loop(void) {
    if (newCodeFlag) {
        __disable_irq();
        uint32_t codeToProcess = lastCodeFromISR;
        newCodeFlag = 0;
        __enable_irq();

        switch (codeToProcess) {
            case IR_POWER:  // LED ON/OFF toggle (OFF->HIGH, or ON->OFF)
                if(LightLevel == 0) LightLevel = 3;
                else LightLevel = 0;
                updateLED();
                break;
            case IR_PLAYPAUSE: // Fan toggle 50%
                FanStatus = !FanStatus;
                updateFan(FanStatus ? 50 : 0); // Use ternary operator for concise control
                break;
            case IR_1: updateFan(FanStatus ? 30 : 0); break; // Fan LOW
            case IR_2: updateFan(FanStatus ? 50 : 0); break; // Fan MED
            case IR_3: updateFan(FanStatus ? 80 : 0); break; // Fan HIGH
            case IR_4: LightLevel = 1; updateLED(); break;  // LED LOW
            case IR_5: LightLevel = 2; updateLED(); break;  // LED MED
            case IR_6: LightLevel = 3; updateLED(); break;  // LED HIGH
            default: break;
        }

        updateLCD(); // Call the centralized LCD update
    }
}

/* Motor configuration */
void motor_config(void) {
    // Initial motor state: OFF
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET); // STBY disabled (low power)

    // Set default direction, even when off
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);   // AIN1 HIGH
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET); // AIN2 LOW

    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0); // PWM 0%
}

/* UART command handler */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART3) {
        if (rx_indx == 0) memset(rx_buffer, 0, sizeof(rx_buffer));

        if (rx_data[0] != '\r') {
            rx_buffer[rx_indx++] = rx_data[0];
        } else {
            rx_indx = 0;
            transfer_cplt = 1;

            if(strcmp((char*)rx_buffer,"Light ON")==0) { LightLevel=3; updateLED(); }
            else if(strcmp((char*)rx_buffer,"Light OFF")==0){ LightLevel=0; updateLED(); }
            else if(strcmp((char*)rx_buffer,"LED LOW")==0){ LightLevel=1; updateLED(); }
            else if(strcmp((char*)rx_buffer,"LED MEDIUM")==0){ LightLevel=2; updateLED(); }
            else if(strcmp((char*)rx_buffer,"LED HIGH")==0){ LightLevel=3; updateLED(); }
            else if(strcmp((char*)rx_buffer,"Fan OFF")==0){ FanStatus=0; updateFan(0); }
            else if(strcmp((char*)rx_buffer,"Fan ON")==0){ FanStatus=1; updateFan(25); }
            else if(strcmp((char*)rx_buffer,"Fan Speed 1")==0){ updateFan(FanStatus ? 30 : 0); }
            else if(strcmp((char*)rx_buffer,"Fan Speed 2")==0){ updateFan(FanStatus ? 50 : 0); }
            else if(strcmp((char*)rx_buffer,"Fan Speed 3")==0){ updateFan(FanStatus ? 80 : 0); }

            updateLCD(); // Call the centralized LCD update

            HAL_UART_Transmit(&huart3,(uint8_t*)"\n\r",2,100);
        }

        HAL_UART_Receive_IT(&huart3, rx_data, 1);
        HAL_UART_Transmit(&huart3, rx_data, 1, 100);
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	while (1) {
		/* Add error handling logic, e.g., an infinite loop or LED blink */
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
